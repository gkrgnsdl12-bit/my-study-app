import flet as ft

def main(page: ft.Page):
    # 페이지 기본 설정 (문자열로 정렬 설정)
    page.title = "기술사 하이패스 복습"
    page.vertical_alignment = "center"
    page.horizontal_alignment = "center"
    page.theme_mode = "light"
    page.window_width = 400
    page.window_height = 700

    # 샘플 데이터 (조명 + 동력 통합)
    questions = [
        {"q": "와이-델타(Y-Δ) 기동의 목적은?", "a": "기동전류를 1/3로 줄여 선로와 모터를 보호", "tags": ["기동전류 1/3", "토크 1/3", "감압기동"]},
        {"q": "EOCR의 주요 역할은?", "a": "과전류, 결상, 구속 등 이상 상태 감지 및 차단", "tags": ["과전류 보호", "결상 감지", "전자식"]},
        {"q": "조명 설계 시 '글레어' 대책은?", "a": "휘도가 높은 광원을 직접 보지 않게 차광각 조절", "tags": ["차광각(Cut-off)", "루버 설치", "반사율 조절"]}
    ]
    
    current_idx = 0

    # UI 구성 요소들
    lbl_title = ft.Text("전기기술사 복습", size=26, weight="bold", color="blue")
    lbl_question = ft.Text(questions[current_idx]["q"], size=22, text_align="center")
    lbl_answer = ft.Text("", size=18, color="blue700", visible=False, italic=True)
    
    # 체크리스트 영역
    check_container = ft.Column(visible=False, horizontal_alignment="start")

    def update_checklists(idx):
        check_container.controls = [ft.Checkbox(label=tag) for tag in questions[idx]["tags"]]

    update_checklists(current_idx)

    # 정답 확인 버튼 클릭 시
    def show_answer(e):
        lbl_answer.value = f"💡 정답: {questions[current_idx]['a']}"
        lbl_answer.visible = True
        check_container.visible = True
        btn_confirm.visible = False
        row_feedback.visible = True
        page.update()

    # 난이도 선택 및 다음 문제로 이동
    def next_question(status):
        nonlocal current_idx
        current_idx = (current_idx + 1) % len(questions)
        
        lbl_question.value = questions[current_idx]["q"]
        lbl_answer.visible = False
        update_checklists(current_idx)
        check_container.visible = False
        btn_confirm.visible = True
        row_feedback.visible = False
        page.update()

    btn_confirm = ft.ElevatedButton(
        "정답 확인하기", 
        on_click=show_answer, 
        width=250
    )
    
    # 하단 피드백 버튼 (아이콘 이름도 문자열로 처리)
    row_feedback = ft
